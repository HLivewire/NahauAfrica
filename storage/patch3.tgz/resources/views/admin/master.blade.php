<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    @php
    $settings = settings();
    @endphp
    <meta charset="{{ config('app.charset') }}">
    <meta name="viewport" content="{{ __('width=device-width, initial-scale=1') }}">
    <!-- favicon -->
    <link rel="icon" href="{{ media_url($settings->favicon) }}">
    <meta name="csrf-token">
    <title>{{ $settings->title }}</title>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="{{ asset('adminassets/fonts/google-font-sans-pro.css') }}">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/fontawesome-free/css/all.min.css') }}">
    <!-- Ionicons 2.0.1 -->
    <link rel="stylesheet" href="{{ asset('adminassets/fonts/docs/css/ionicons.min.css') }}">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css') }}">
    <!-- iCheck -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/icheck-bootstrap/icheck-bootstrap.min.css') }}">
    <!-- JQVMap -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/jqvmap/jqvmap.min.css') }}">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('adminassets/dist/css/adminlte.min.css') }}">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css') }}">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/daterangepicker/daterangepicker.css') }}">
    <!-- summernote -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/summernote/summernote-bs4.min.css') }}">
    <!-- maan-custom css 1.0.0 -->
    <link rel="stylesheet" href="{{ asset('adminassets/css/maan-custom.css') }}">
    <!-- toastr -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/toastr/toastr.css') }}">
    <!-- toastr -->
</head>
<body  class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
@include('admin.layouts.header')
<!-- /.navbar -->

    <!-- Main Sidebar Container -->
@include('admin.layouts.sidebar')

<!-- Content Wrapper. Contains page content -->
    <!-- CSS. Contains page content -->

@yield('css_content')

<!-- Main. Contains page content -->
@yield('main_content')

<!-- /.content-wrapper -->
@include('admin.layouts.footer')

<!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->

<script src="{{ asset('adminassets/plugins/jquery/jquery.min.js') }}"></script>
<!-- jQuery UI 1.11.4 -->
<script src="{{ asset('adminassets/plugins/jquery-ui/jquery-ui.min.js') }}"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<!-- JS. Contains page content -->
@yield('js_content')

<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="{{ asset('adminassets/plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
@if(\Route::current()->getName() == 'admin.subscriber' ||Route::current()->getName() == 'admin.contact')
    <!-- DataTables  & Plugins -->
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css') }}">
    <script src="{{ asset('adminassets/plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/datatables-buttons/js/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/jszip/jszip.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/pdfmake/pdfmake.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/pdfmake/vfs_fonts.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/datatables-buttons/js/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/datatables-buttons/js/buttons.print.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/datatables-buttons/js/buttons.colVis.min.js') }}"></script>
    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                /*"buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]*/
                "buttons": ["csv"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>
    @endif
<!-- ChartJS -->
<script src="{{ asset('adminassets/plugins/chart.js/Chart.min.js') }}"></script>


<!-- jQuery Knob Chart -->
<script src="{{ asset('adminassets/plugins/jquery-knob/jquery.knob.min.js') }}"></script>
<!-- daterangepicker -->
<script src="{{ asset('adminassets/plugins/moment/moment.min.js') }}"></script>
<script src="{{ asset('adminassets/plugins/daterangepicker/daterangepicker.js') }}"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="{{ asset('adminassets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js') }}"></script>
<!-- Summernote -->
<script src="{{ asset('adminassets/plugins/summernote/summernote-bs4.min.js') }}"></script>
<!-- overlayScrollbars -->
<script src="{{ asset('adminassets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js') }}"></script>
<!-- AdminLTE App -->
<script src="{{ asset('adminassets/dist/js/adminlte.js') }}"></script>
<!-- AdminLTE for demo purposes -->
<script src="{{ asset('adminassets/dist/js/demo.js') }}"></script>

@if (\Route::current()->getName() == 'admin.dashboard')
    <!-- Sparkline -->
    <script src="{{ asset('adminassets/plugins/sparklines/sparkline.js') }}"></script>
    <!-- JQVMap -->
    <script src="{{ asset('adminassets/plugins/jqvmap/jquery.vmap.min.js') }}"></script>
    <script src="{{ asset('adminassets/plugins/jqvmap/maps/jquery.vmap.usa.js') }}"></script>
    <script src="{{ asset('adminassets/dist/js/pages/dashboard.js') }}"></script>
@endif
@if(\Route::current()->getName() != 'admin.dashboard')
    <audio id="myAudio">

        <source src="{{ asset('audio/notification_up.mp3') }}" type="audio/mp3">
    </audio>
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/sweetalert2/animate.min.css') }}"/>
    <script src="{{ asset('adminassets/plugins/sweetalert2/sweetalert2.all.min.js') }}" type="text/javascript"></script>
    <link rel="stylesheet" href="{{ asset('adminassets/plugins/sweetalert2/sweetalert2.min.css') }}">
    <script src="{{ asset('adminassets/js/custom-sweetalert2.js') }}" type="text/javascript"></script>

@endif

    <script src="{{ asset('adminassets/js/custom-ajax.js') }}" type="text/javascript"></script>
{{-- Custom Js--}}
<script src="{{ asset('adminassets/js/maan-custom.js') }}"></script>

<!-- Select2 -->
<link rel="stylesheet" href="{{ asset('adminassets/plugins/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('adminassets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}">
<script src="{{ asset('adminassets/plugins/select2/js/select2.full.min.js') }}"></script>
<!-- toastr -->
<script src="{{ asset('adminassets/plugins/toastr/toastr.min.js') }} "></script>


<script>
    $(function () {
        // Summernote
        $('#summernote').summernote();
    })
</script>
<script>

    $(function () {
        //Initialize Select2 Elements
        $('.select2').select2();

        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        });
        //Date picker
        $('#reservationdate').datetimepicker({
            format: 'L'
        });

        $("input[data-bootstrap-switch]").each(function(){
            $(this).bootstrapSwitch('state', $(this).prop('checked'));
        })

    })
</script>
<script type="text/javascript">

    var message = "{{session('message')}}";
    if (message!='') {

        if (message=='Inserted'){
            onSubmitInsert()
        }else if( message=='Updated'){
            onSubmitUpdate()
        }else if( message=='Generated'){
            onSubmitGenerate()

        }
    }
    function onSubmitGenerate(){
        Swal.fire({
            position: 'top-center',
            icon: 'success',
            title: 'Data Generated successfully!',
            showConfirmButton: false,
            timer: 1500,
            onOpen: function() {
                var maanlms = document.getElementById("myAudio");
                maanlms.play();
            }
        })
    }

</script>


</body>
</html>
