(function () {
  var drawer = document.getElementById('nahauDrawer');
  var overlay = document.getElementById('nahauOverlay');
  if (!drawer || !overlay) return;
  var lastFocus = null;

  function open() {
    lastFocus = document.activeElement;
    drawer.classList.add('is-open');
    overlay.classList.add('is-open');
    drawer.setAttribute('aria-hidden', 'false');
    document.body.classList.add('nahau-lock');
    setTimeout(function () { var f = document.getElementById('nahauEmail'); if (f) f.focus(); }, 700);
  }
  function close() {
    drawer.classList.remove('is-open');
    overlay.classList.remove('is-open');
    drawer.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('nahau-lock');
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-nahau-open="drawer"]')) { e.preventDefault(); open(); }
    else if (e.target.closest('[data-nahau-close="drawer"]')) { close(); }
  });
  overlay.addEventListener('click', close);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });

  // Re-open after a failed sign in so the error message is visible.
  if (drawer.querySelector('[data-nahau-autoopen]')) { setTimeout(open, 150); }
})();
